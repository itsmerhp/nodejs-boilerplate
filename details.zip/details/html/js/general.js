$(document).ready(function() {
    //Prevent Page Reload on all # links
    $("a[href='#']").click(function(e) {
    	e.preventDefault();
    });



    // On scroll header small
    $(window).scroll(function(e) {
    	if ($(window).scrollTop() > 0)
    		$(".wrapper").addClass('small-header');
    	else
    		$(".wrapper").removeClass('small-header');
    });


    $("[placeholder]").each(function() {
    	$(this).attr("data-placeholder", this.placeholder);

    	$(this).bind("focus", function() {
    		this.placeholder = '';
    	});
    	$(this).bind("blur", function() {
    		this.placeholder = $(this).attr("data-placeholder");
    	});
    });


    /* Device Summary toggle*/
    $('.primary-button').click(function(){ 
        $(".device-summary-section").toggleClass('select') 
    });

    /* Select Device Category Carousel */
    $('.device-carousel').owlCarousel({
    	loop: true,
    	margin: 30,
    	nav: true,
    	stagePadding: 254,
    	/*autoplay:true,*/
    	autoplayTimeout: 2000,
    	autoplayHoverPause: true,
    	navigation: true,
    	dots: false,
    	responsive: {
    		0: {
    			items: 1,
    			stagePadding: 0
    		},
    		640: {
    			items: 2,
    			stagePadding: 0
    		},
    		1024: {
    			items: 3,
    			stagePadding: 0
    		},
    		1360: {
    			items: 4,
    			stagePadding: 0
    		},
    		1920: {
    			items: 4
    		},
            2500: {
                items: 6
            }
        },
    });

    $(".owl-prev").html('<i><img src="images/left-arrow.svg" alt="Left Arrow"></i>');
    $(".owl-next").html('<i><img src="images/right-arrow.svg" alt="Right Arrow"></i>');

    /*Dropkick Dropdown*/
    $("#select, .archives-month, .request-dropdown").dropkick({
    	mobile: true
    });

    //imagefill
    $(".right-inner-block").imagefill();


    $("#toggle-icon").click(function() {
        $(this).toggleClass('open');
        $(".overlay").toggleClass("close");
        if ($(".overlay").hasClass("close")) {
            $("#toggle-menu i").removeClass("fa-times").addClass("fa-bars");
        } else {
            $("#toggle-menu i").removeClass("fa-bars").addClass("fa-times");
        }
    });



});




$(window).load(function() {
	setTimeout(function() {
		$("img").css({ opacity: 1 });
	}, 1000);
});
